

<!-- <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<title> janken.php </title>
	<link rel="stylesheet" href="css_main.css" type="text/css" media="all" />
</head>
<body>
	<h1>janken.php</h1>
	<div class="main">
		<form id="janken" method="GET" action="janken02-2.php">
		<h2>じゃんけん？</h2>
		<div>
			<select name="janken">
				<option value="goo">グー！</option>
				<option value="choki">チョキ！</option>
				<option value="paa">パー！</option>
			</select>
			<br />
			<br />
			<input type="submit" value="勝負！" />
		</div>
		</form>
	</div>
</body>
</html> -->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="Content-Style-Type" content="text/css" />
	<title> janken.php </title>
	<link rel="stylesheet" href="css_main.css" type="text/css" media="all" />
</head>
<body>
	<h1>janken.php</h1>
	<div class="main">
		<form id="janken" method="GET" action="jyanken02-2.php">
		<h2>じゃんけん？</h2>
		<div>
			<select name="janken">
				<option value="goo">グー！</option>
				<option value="choki">チョキ！</option>
				<option value="paa">パー！</option>
			</select>
			<br />
			<br />
			<input type="submit" value="勝負！" />
		</div>
		</form>
	</div>
	<script type="text/javascript">
	</script>
</body>
</html>